//
//  APIManager.swift
//  ImageUploader
//
//  Created by singsys on 26/02/24.
//

import Foundation
class APIManager{
//    static let shared: APIManager = {
//        
//        var instance = APIManager()
//        
//        let urlconfig = URLSessionConfiguration.default
//        urlconfig.timeoutIntervalForRequest = 45
//        urlconfig.timeoutIntervalForResource = 60
//        instance.urlSession = Foundation.URLSession(configuration: urlconfig, delegate: nil, delegateQueue: OperationQueue.main)
//        
//        URLCache.shared.removeAllCachedResponses()
//        
//        return instance
//    }()   
   
    
    
    
}
