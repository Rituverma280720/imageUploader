//
//  ViewController.swift
//  ImageUploader
//
//  Created by singsys on 26/02/24.
//

import UIKit

struct RequestParameters: Codable {
    let user_id: String
    let offset: String
    let type: String
}
class ViewController: UIViewController{

    @IBOutlet weak var loadbtn: UIButton!
    @IBOutlet weak var imageTableView: UITableView!
    
    var images: [Images]?
    var height:CGFloat?
    var increament = 0;
    var array: [Images]?
    weak var delegate: ImageHeightDelegate?
    override func viewDidLoad() {
        super.viewDidLoad()
        registercell()
        calldataSource()
        getImageList(offset: increament)
        title = "Images"
    }
    
    private var urlSession: URLSession!
   
  
    func registercell(){
        imageTableView.register(UINib(nibName: "ImageTableViewCell", bundle: nil), forCellReuseIdentifier: "ImageTableViewCell")
    }
    func calldataSource(){
        imageTableView.delegate = self
        imageTableView.dataSource = self
    }
    
    @IBAction func loadMoreImages(_ sender: Any) {
          increament+=1
        getImageList(offset: increament)
       

    }
    
    
    func getImageList(offset: Int){
        fetchImageList(offset: offset, completionHander: { (imagesListModel, error)  in
            if let error = error {
                    print("Error fetching image list: \(error.localizedDescription)")
                    // Handle the error
                    return
                }
            
            
                // Check if imagesListModel is not nil
                guard let imagesListModel = imagesListModel else {
                    print("No image list data received")
                    // Handle the case where no data is received
                    return
                }
          
            if (offset >= 2) {
               // self.increament+=1
                self.array = imagesListModel.images
                print("Images:",self.images)
                self.images?.append(contentsOf: self.array ?? [])
                print("Images:",self.images)
            }
            else{
                self.images = imagesListModel.images
            }
           // self.images?.append(contentsOf:imagesListModel?.images ?? [])
            
            
            DispatchQueue.main.async {
                self.imageTableView.reloadData()
            }
        })
        
    }
    
    func fetchImageList(offset: Int, completionHander: @escaping (ImagesListModel?, Error?) -> Void) {
        let parameters = [
            [
                "key": "user_id",
                "value": "108",
                "type": "text"
            ],
            [
                "key": "offset",
                "value": "\(offset)",
                "type": "text"
            ],
            [
                "key": "type",
                "value": "popular",
                "type": "text"
            ]
        ] as [[String: Any]]

        let boundary = "Boundary-\(UUID().uuidString)"
        var body = Data()

        for param in parameters {
            let paramName = param["key"] as! String
            body.append(Data("--\(boundary)\r\n".utf8))
            body.append(Data("Content-Disposition: form-data; name=\"\(paramName)\"\r\n\r\n".utf8))
            let paramValue = param["value"] as! String
            if let paramData = paramValue.data(using: .utf8) {
                body.append(paramData)
            } else {
                print("Error converting parameter value to data")
            }
            body.append(Data("\r\n".utf8))
        }

        body.append(Data("--\(boundary)--\r\n".utf8))

        var request = URLRequest(url: URL(string: "https://dev3.xicom.us/xttest/getdata.php")!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        request.httpBody = body

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error: \(error)")
                completionHander(nil, error)
                return
            }

            guard let data = data else {
                print("No data received")
                let error = NSError(domain: "No data received", code: 0, userInfo: nil)
                completionHander(nil, error)
                return
            }

            do {
                let filmSummary = try JSONDecoder().decode(ImagesListModel.self, from: data)
                print("Decoded data: \(filmSummary)")
                completionHander(filmSummary, nil)
            } catch {
                print("Error decoding data: \(error)")
                completionHander(nil, error)
            }
        }

        task.resume()
    }
    func findImageHeight(from imageData: Data) -> CGFloat? {
        guard let downloadedImage = UIImage(data: imageData) else {
            print("Error: Unable to create image from data.")
            return nil
        }
        
        let height = downloadedImage.size.height
        return height
    }

 
}














extension ViewController: UITableViewDelegate, UITableViewDataSource, ImageHeightDelegate{
    func imageHeightUpdated() {
        imageTableView.beginUpdates()
        imageTableView.endUpdates()
    }
    
    func reloadCell(at indexPath: IndexPath) {
        DispatchQueue.main.async {
            
                   self.imageTableView.reloadRows(at: [indexPath], with: .automatic)
               }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return images?.count ?? 0
    }
    

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = imageTableView.dequeueReusableCell(withIdentifier: "ImageTableViewCell", for: indexPath) as! ImageTableViewCell
        
        if let images = images, indexPath.row < images.count {
            let image = images[indexPath.row]
            
            if let imageUrlString = image.xt_image, let imageUrl = URL(string: imageUrlString) {
                let task = URLSession.shared.dataTask(with: imageUrl) { data, response, error in
                    guard let data = data, let downloadedImage = UIImage(data: data) else {
                        // Handle error or set a placeholder image
                        return
                    }
                    if let heightData = self.findImageHeight(from: data) {
                        self.height = heightData
                        print("The height of the image is \(String(describing: self.height)) pixels.")
                    }
                    
                    DispatchQueue.main.async {
                      //  cell.heightConstraints.constant = self.height!
                        self.delegate?.imageHeightUpdated()
                        cell.configure(withImage: downloadedImage, height: self.height!)
                       // cell.showImageView.image = downloadedImage
                        
                        tableView.beginUpdates()
                        tableView.endUpdates()
                    }
                }
                task.resume()
            }
        }
        
        return cell
    }


    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        guard let  vc = self.storyboard?.instantiateViewController(withIdentifier: "DetailsViewController") as? DetailsViewController
//               else {return}
       let vc = DetailScreenViewController()
        
        let selectedImage = images?[indexPath.row]
        print("selectedImage", selectedImage)
        vc.imageData = selectedImage
        navigationController?.pushViewController(vc, animated: true)
    
    
       // performSegue(withIdentifier: "DetailsViewController", sender: nil)
        
    }
    
    
}
