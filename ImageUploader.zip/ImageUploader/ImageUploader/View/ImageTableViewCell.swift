//
//  ImageTableViewCell.swift
//  ImageUploader
//
//  Created by singsys on 26/02/24.
//

import UIKit
protocol ImageHeightDelegate: AnyObject {
    func imageHeightUpdated()
}
class ImageTableViewCell: UITableViewCell {

    @IBOutlet weak var heightConstraints: NSLayoutConstraint!
    
    @IBOutlet weak var showImageView: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        showImageView.layer.masksToBounds = true
        showImageView.layer.borderWidth = 1.5
        showImageView.layer.borderColor = UIColor.black.cgColor
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func configure(withImage image: UIImage, height: CGFloat) {
            // Set the image to the image view
        showImageView.image = image
            
            // Set the height constraint of the image view
        heightConstraints.constant = height
        }
}
