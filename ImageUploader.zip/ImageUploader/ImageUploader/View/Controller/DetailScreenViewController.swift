//
//  DetailScreenViewController.swift
//  ImageUploader
//
//  Created by singsys on 28/02/24.
//

import UIKit

class DetailScreenViewController: UIViewController {
  
    

    @IBOutlet weak var firstName: UITextField!
    @IBOutlet weak var detailImageView: UIImageView!
    
    @IBOutlet weak var lastName: UITextField!
    
    @IBOutlet weak var email: UITextField!
   
    @IBOutlet weak var phoneNumber: UITextField!
    
    var imageData: Images?
    var indexValue: Int?
    override func viewDidLoad() {
        super.viewDidLoad()
       
       
        let tap = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard1))
               view.addGestureRecognizer(tap)
        setImageData()

    }
    @objc func dismissKeyboard1() {
        view.endEditing(true)
    }
    
    @IBAction func submitbtnAction(_ sender: Any) {
        
        guard validated() else {
                  return
              }
           let userDetails = UserDetails(firstName: firstName.text ?? "",
                                          lastName: lastName.text ?? "",
                                          email: email.text ?? "",
                                          phone: phoneNumber.text ?? "",
                                          userImage: detailImageView.image)
              postData(userDetails: userDetails)
        
    }
    func setImageData() {
        
        if let imageUrlString = imageData?.xt_image, let imageUrl = URL(string: imageUrlString) {
            let task = URLSession.shared.dataTask(with: imageUrl) { data, response, error in
                guard let data = data, let downloadedImage = UIImage(data: data) else {
                    // Handle error or set a placeholder image
                    return
                }
                DispatchQueue.main.async {
                    self.detailImageView.image = downloadedImage
                }
            }
            task.resume()
        }
    }
    private func postData(userDetails: UserDetails) {
   
        // Define the server URL
            guard let url = URL(string: "https://dev3.xicom.us/xttest/savedata.php") else {
                print("Invalid URL")
                return
            }

            // Create URLRequest
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
           
        // Boundary for multipart request
        let boundary = "Boundary-\(UUID().uuidString)"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        // Body of the request
        var body = Data()
        
        // Add user details
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"first_name\"\r\n\r\n".data(using: .utf8)!)
        body.append("\(userDetails.firstName)\r\n".data(using: .utf8)!)
        
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"last_name\"\r\n\r\n".data(using: .utf8)!)
        body.append("\(userDetails.lastName)\r\n".data(using: .utf8)!)
        
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"email\"\r\n\r\n".data(using: .utf8)!)
        body.append("\(userDetails.email)\r\n".data(using: .utf8)!)
        
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"phone\"\r\n\r\n".data(using: .utf8)!)
        body.append("\(userDetails.phone)\r\n".data(using: .utf8)!)

        // Add image data
        if let image = userDetails.userImage,
           let imageData = image.jpegData(compressionQuality: 1.0) {
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"user_image\"; filename=\"image.jpg\"\r\n".data(using: .utf8)!)
            body.append("Content-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)
            body.append(imageData)
            body.append("\r\n".data(using: .utf8)!)
        }
        
        // End boundary
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
        
        request.httpBody = body
        
        // Create URLSession task
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error: \(error)")
                return
            }
            
            guard let response = response as? HTTPURLResponse else {
                print("Invalid response")
                return
            }
            
            print("Response status code: \(response.statusCode)")
            
            if let data = data {
                // Parse response data if needed
                print("Response data: \(String(data: data, encoding: .utf8) ?? "")")
            }
            DispatchQueue.main.async {
                do {
                    if let data = data {
                    if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                        if let message = json["message"] as? String {
                         self.showAlertResponse(message: message)
                            
                        } else {
                            print("Message not found in API response.")
                        }
                    } else {
                        print("Invalid JSON format in API response.")
                    }
                }
                } catch {
                    print("Error deserializing JSON: \(error)")
                }
            }
        }
        task.resume()
       }
    
    private func showAlertResponse(message: String, cancelButtonCallback: (() -> Void)? = nil) {
        let alertController = UIAlertController(title: "ImageUpdater", message: message, preferredStyle: .alert)
        
        alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in
            
            self.pop() // Dismiss the view controller
        }))
        
        self.present(alertController, animated: true, completion: nil)
    }
    private func validated() -> Bool {
        if Validator.emptyString(firstName.text) {
            showAlertWith(message: "Please enter your first name")
            return false
        } else if Validator.emptyString(lastName.text) {
            showAlertWith(message: "Please enter your last name")
            return false
        } else if !Validator.validEmail(email.text) {
            showAlertWith(message: "Please enter valid email address")
            return false
        } else if !Validator.validBadgeNumber(phoneNumber.text) {
            showAlertWith(message: "Please enter valid phone number")
            return false
        }
        return true
    }
}
