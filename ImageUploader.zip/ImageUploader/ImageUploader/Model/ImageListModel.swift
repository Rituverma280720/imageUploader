//
//  ImageListModel.swift
//  ImageUploader
//
//  Created by singsys on 26/02/24.
//

import Foundation
struct ImagesListModel : Codable {
    let status : String?
    let images : [Images]?

    enum CodingKeys: String, CodingKey {

        case status = "status"
        case images = "images"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        status = try values.decodeIfPresent(String.self, forKey: .status)
        images = try values.decodeIfPresent([Images].self, forKey: .images)
    }

}

struct Images: Codable {
    let xt_image : String?
    let id : String?

    enum CodingKeys: String, CodingKey {

        case xt_image = "xt_image"
        case id = "id"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        xt_image = try values.decodeIfPresent(String.self, forKey: .xt_image)
        id = try values.decodeIfPresent(String.self, forKey: .id)
    }

}
