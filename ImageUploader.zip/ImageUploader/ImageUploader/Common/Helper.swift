//
//  Helper.swift
//  ImageUploader
//
//  Created by singsys on 27/02/24.
//

import Foundation
import UIKit
extension UIViewController{
    func push(_ viewController: UIViewController, animated: Bool = true) -> Void {
        navigationController?.pushViewController(viewController, animated: animated)
    }
    func pop(animated: Bool = true) {
        navigationController?.popViewController(animated: animated)
    }
  
    func showAlertWith(message: String, cancelButtonCallback: (() -> Void)? = nil) {
        let alertController = UIAlertController(title: "ImageUpdater", message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { (action) in
            cancelButtonCallback?()
        }))
        
        self.present(alertController, animated: true, completion: nil)
    }
   
}

struct Validator {
    
    static func emptyString(_ string: String?) -> Bool {
        return filter(string: string).isEmpty
    }
    
    static func filter(string: String?) -> String {
        if string == nil || string!.isKind(of: NSNull.self) || string == "null" || string == "<null>" || string == "(null)" {
            return ""
        }
        
        return string!.trimmingCharacters(in: CharacterSet.whitespaces)
    }
    
    static func validEmail(_ email: String?) -> Bool {
        guard let emailAddress = email,
            !emptyString(emailAddress) else {
                return false
        }
        
        let filteredEmail = emailAddress.trimmingCharacters(in: CharacterSet.whitespaces)
//        let regex = "(?:[\\p{L}0-9!#$%\\&'*+/=?\\^_`{|}~-]+(?:\\.[\\p{L}0-9!#$%\\&'*+/=?\\^_`{|}" +
//            "~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\" +
//            "x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[\\p{L}0-9](?:[a-" +
//            "z0-9-]*[\\p{L}0-9])?\\.)+[\\p{L}0-9](?:[\\p{L}0-9-]*[\\p{L}0-9])?|\\[(?:(?:25[0-5" +
//            "]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-" +
//            "9][0-9]?|[\\p{L}0-9-]*[\\p{L}0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21" +
//        "-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])"
        
        let regex = "[A-Z0-9a-z.-_]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,3}"
        
        let emailValidator = NSPredicate(format:"SELF MATCHES %@", regex)
        return emailValidator.evaluate(with: filteredEmail)
    }
    
    static func validBadgeNumber(_ number: String?) -> Bool {
        if emptyString(number) {
            return false
        }
        
        return (number!.count > 4 && number!.count < 10)
    }
    
}

extension UIImageView {
    func downloaded(from url: URL, contentMode mode: ContentMode = .scaleAspectFit) {
        contentMode = mode
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }
            DispatchQueue.main.async() { [weak self] in
                self?.image = image
            }
        }.resume()
    }
    func downloaded(from link: String, contentMode mode: ContentMode = .scaleAspectFit) {
        guard let url = URL(string: link) else { return }
        downloaded(from: url, contentMode: mode)
    }
}

struct UserDetails {
    var firstName: String
    var lastName: String
    var email: String
    var phone: String
    var userImage: UIImage?
}
